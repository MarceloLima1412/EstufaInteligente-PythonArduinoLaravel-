<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Moisture extends Authenticatable
{
   
    protected $fillable = [
        'id', 'moisture', 'data'
    ];

}
