<?php $__env->startSection('title', 'Lista de Medida de Agua'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($moistures)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Percentagem de Humidade</th>
            <th>Data</th>            
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $moistures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moisture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($moisture->moisture); ?></td>
            <td><?php echo e($moisture->data); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <h2>Não foram encontradas medidas de Humidade</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/ainet/ess_prj/resources/views/moistures/index.blade.php ENDPATH**/ ?>