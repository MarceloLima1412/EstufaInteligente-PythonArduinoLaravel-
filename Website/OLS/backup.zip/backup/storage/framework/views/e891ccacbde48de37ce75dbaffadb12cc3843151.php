<?php $__env->startSection('title', 'Lista de Medida de Agua'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($aguas)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Quantidade de Agua</th>
            <th>Data</th>            
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $aguas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($agua->qtdAgua); ?></td>
            <td><?php echo e($agua->data); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <h2>Não foram encontradas medidas de agua</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/sites/ESS-Projeto/resources/views/agua/index.blade.php ENDPATH**/ ?>