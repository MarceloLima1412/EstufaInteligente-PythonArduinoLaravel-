<?php $__env->startSection('title', 'Lista de Utilizadores'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($users)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>E-mail</th>     
            <th>Tipo de Utilizador</th>       
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->tipo_user); ?></td>
            <td><form  method="POST"  action="<?php echo e(route('users.ativar', $user)); ?>"role="form" class="inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <input type = "hidden" name="ativar" value="">
                    <button type="submit" class="btn btn-primary">Anonimo/Funcionario</button>
            </form>
        </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <h2>Não foram encontrados utilizadores
    </h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/sites/ESS-Projeto/resources/views/users/index.blade.php ENDPATH**/ ?>