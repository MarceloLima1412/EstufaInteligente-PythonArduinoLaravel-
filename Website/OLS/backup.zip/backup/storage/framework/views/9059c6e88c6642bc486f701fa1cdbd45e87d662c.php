<?php $__env->startSection('title', 'Atuadores'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($atuadores)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Nome do Atuador</th>
            <th>Ativo</th>        
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $atuadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atuadore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($atuadore->tipo); ?></td>
            <td><?php echo e($atuadore->ativo); ?></td>
            <td><form  method="POST"  action="<?php echo e(route('atuadores.ativar', $atuadore)); ?>"role="form" class="inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <input type = "hidden" name="ativar" value="">
                    <button type="submit" class="btn btn-primary">Ativar/Desativar</button>
            </form>
        </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php else: ?>
    <h2>Não foram encontrados atuadores</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/368/9875368/resources/views/atuadore/index.blade.php ENDPATH**/ ?>